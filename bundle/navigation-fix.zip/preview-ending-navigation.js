/* Gallery gestures stay inside the preview; a dedicated button opens the ending. */
(()=>{'use strict';
const preview=document.querySelector('#preview');if(!preview)return;
const blocked=event=>document.querySelector('dialog[open]')||event.target.closest?.('input,textarea,select,[contenteditable="true"]');
function scrollable(target,direction){for(let element=target instanceof Element?target:null;element&&element!==preview;element=element.parentElement){if(element.matches('.runway-index,.preview-tabs,[data-preview-scroll]')){const maximum=element.scrollHeight-element.clientHeight;if(maximum>2&&(direction>0?element.scrollTop<maximum-2:element.scrollTop>2))return true}}return false}
// These bubble listeners run after gallery handlers. They only stop unused gestures
// from scrolling the outer page; they never step a gallery or switch a section.
preview.addEventListener('wheel',event=>{if(event.defaultPrevented||event.ctrlKey||event.metaKey||event.shiftKey||blocked(event)||Math.abs(event.deltaX)>=Math.abs(event.deltaY)||scrollable(event.target,event.deltaY))return;event.preventDefault()},{passive:false});
preview.addEventListener('touchmove',event=>{if(event.defaultPrevented||event.touches.length!==1||blocked(event)||scrollable(event.target,1)||scrollable(event.target,-1))return;event.preventDefault()},{passive:false});
document.addEventListener('click',event=>{if(event.ctrlKey||event.metaKey||event.shiftKey||event.altKey||blocked(event))return;const link=event.target.closest?.('.runway-continue');if(link?.hash!=='#ending'||document.body.dataset.section!=='preview')return;event.preventDefault();event.stopImmediatePropagation();document.querySelector('[data-nav="ending"]')?.click()},{capture:true});
document.documentElement.dataset.previewEndingNavigation='button-only';
})();
