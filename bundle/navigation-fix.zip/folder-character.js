(()=>{
const poses=['眨眼微笑','惊讶','鼓脸','大笑','坏笑','挑眉疑惑'];
const expressionFrames=[0,1,2,3,4,5];
function setExpression(face,index){face.toggleAttribute('data-ui',index===6);if(index===6){face.textContent='UI';return}face.textContent='';const frame=expressionFrames[index]??1;face.style.setProperty('--face-x',(frame%3)*50+'%');face.style.setProperty('--face-y',frame<3?'0%':'100%');face.dataset.expressionFrame=String(frame)}
function character(index,extra=''){const face=document.createElement('span');face.className='character-sticker '+extra;setExpression(face,index);face.setAttribute('aria-hidden','true');return face}
const items=[...document.querySelectorAll('#folders .folder-item')];
items.forEach((item,index)=>{const preview=item.querySelector('.file-preview');preview.replaceChildren(character(index));preview.classList.add('character-card');const badge=document.createElement('i');badge.className='character-card-number';badge.textContent=String(index+1).padStart(2,'0');preview.append(badge);item.dataset.expression=poses[index]||'界面设计'});
const cover=document.querySelector('.folder-cover');cover.append(character(0,'cover-character'));
const decorations=[['cover-tape','MAKE SOME TROUBLE'],['cover-stamp','100% ME'],['cover-note','灵感出没！'],['cover-zigzag','↯'],['cover-spark','✦'],['cover-orbit','✳']];
for(const [name,label] of decorations){const sticker=document.createElement('span');sticker.className='cover-decoration '+name;sticker.textContent=label;sticker.setAttribute('aria-hidden','true');cover.append(sticker)}
const paper=document.querySelector('#folder-paper');const paperFace=character(0,'paper-character');paper.append(paperFace);
function update(){const index=Number(paper.dataset.select||0);setExpression(paperFace,index)}
new MutationObserver(update).observe(paper,{attributes:true,attributeFilter:['data-select']});update();
})();
