/* One gesture owns one surface: gallery, résumé, folder or chapter margin. */
(()=>{'use strict';
const body=document.body,preview=document.querySelector('#preview'),folder=document.querySelector('#folders .folder-list');
const coarse=matchMedia('(pointer:coarse)'),blocked=()=>document.querySelector('dialog[open]')||body.dataset.collectionTransition;
let gesture=null,lockedUntil=0,wheelSum=0,wheelAt=0;
const mode=()=>body.dataset.section;
function navigate(direction){if(blocked()||performance.now()<lockedUntil)return;const sections=['home','about','folders','preview','ending'],index=sections.indexOf(mode()),next=sections[index+direction];if(!next)return;lockedUntil=performance.now()+1100;gesture=null;document.querySelector('[data-nav="'+next+'"]')?.click()}
function outsideGallery(target){return mode()==='preview'&&!target.closest('.runway-inline,.preview-content-add,.preview-content-manage,input,select,textarea,dialog,.runway-continue')}
function insideInteractive(target){return target.closest('button,a,input,select,textarea,summary,[contenteditable=true]')}
preview.addEventListener('wheel',event=>{if(blocked()||event.ctrlKey||event.metaKey||!event.target.closest('.accordion-gallery,.layout-bounce-stage'))return;event.preventDefault();event.stopImmediatePropagation();const now=performance.now();if(now-wheelAt>280){window.inlineRunwayGallery?.step?.((Math.abs(event.deltaX)>Math.abs(event.deltaY)?event.deltaX:event.deltaY)>0?1:-1);wheelAt=now}},{capture:true,passive:false});
// Empty margins and the six-category directory may change chapters; artwork never does.
preview.addEventListener('wheel',event=>{if(blocked()||event.ctrlKey||event.metaKey||!outsideGallery(event.target)||Math.abs(event.deltaX)>Math.abs(event.deltaY))return;event.preventDefault();event.stopImmediatePropagation();const now=performance.now();if(now-wheelAt>220||Math.sign(wheelSum)!==Math.sign(event.deltaY))wheelSum=0;wheelAt=now;wheelSum+=event.deltaY;if(Math.abs(wheelSum)>=60){navigate(wheelSum>0?1:-1);wheelSum=0}},{capture:true,passive:false});
function start(event){if(blocked()||event.touches.length!==1){gesture=null;return}const touch=event.touches[0],target=event.target,section=mode();let surface='';
 if(outsideGallery(target))surface='chapter';
 else if(section==='folders'&&target.closest('.folder-list'))surface='folder';
 else if(section==='about'&&!target.closest('header,nav,a,button'))surface='resume';
 else if(section==='home'&&!insideInteractive(target))surface='home';
 else if(section==='preview'&&target.closest('.accordion-gallery,.layout-bounce-stage'))surface='gallery';
 if(!surface)return;gesture={surface,target,section,x:touch.clientX,y:touch.clientY,dx:0,dy:0,moved:false,offset:scrollY,handled:false,path:0,lastX:touch.clientX,lastY:touch.clientY};
}
function move(event){const g=gesture;if(!g||event.touches.length!==1||g.section!==mode())return;const touch=event.touches[0];g.path+=Math.hypot(touch.clientX-g.lastX,touch.clientY-g.lastY);g.lastX=touch.clientX;g.lastY=touch.clientY;g.dx=touch.clientX-g.x;g.dy=touch.clientY-g.y;g.moved=Math.hypot(g.dx,g.dy)>12;
 if(g.surface==='chapter'||g.surface==='folder'||g.surface==='home'||g.surface==='resume'||g.surface==='gallery'){event.preventDefault();if(g.surface==='folder')event.stopImmediatePropagation()}
 if(g.surface==='resume'){const section=document.querySelector('#about'),viewport=section.querySelector('.resume-inline-viewport'),doc=section.querySelector('.resume-document'),maximum=Math.max(0,doc.scrollHeight-viewport.clientHeight);scrollTo({top:Math.max(section.offsetTop,Math.min(section.offsetTop+maximum,g.offset-g.dy)),behavior:'instant'})}
 if(g.surface==='home')dispatchEvent(new CustomEvent('portfolio-look',{detail:{clientX:touch.clientX,clientY:touch.clientY}}));
}
function end(event){const g=gesture;gesture=null;if(!g||blocked()||g.section!==mode()||!g.moved)return;
 if(g.surface==='home')dispatchEvent(new Event('portfolio-look-end'));
 const distance=Math.max(Math.abs(g.dx),Math.abs(g.dy));if(distance<34)return;
 if(g.surface==='resume'&&Math.abs(g.dy)>Math.max(75,Math.min(120,innerHeight*.12))&&Math.abs(g.dy)>Math.abs(g.dx)*1.4){const about=document.querySelector('#about'),viewport=about.querySelector('.resume-inline-viewport'),doc=about.querySelector('.resume-document'),maximum=Math.max(0,doc.scrollHeight-viewport.clientHeight),atTop=g.offset<=about.offsetTop+2,atBottom=g.offset>=about.offsetTop+maximum-2;if(g.dy>0&&atTop){event.preventDefault();navigate(-1);return}if(g.dy<0&&atBottom){event.preventDefault();navigate(1);return}}
 if(g.surface==='chapter'&&Math.abs(g.dy)>Math.abs(g.dx)*1.2){event.preventDefault();navigate(g.dy<0?1:-1)}
 if(g.surface==='home'&&Math.hypot(g.dx,g.dy)>=g.path*.82&&Math.abs(g.dy)>Math.max(110,Math.min(160,innerHeight*.16))&&Math.abs(g.dy)>Math.abs(g.dx)*1.6){event.preventDefault();if(g.dy<0)navigate(1)}
 if(g.surface==='gallery'){event.preventDefault();const delta=Math.abs(g.dx)>Math.abs(g.dy)?-g.dx:-g.dy;window.inlineRunwayGallery?.step?.(delta>0?1:-1);suppressClickUntil=performance.now()+450}
 if(g.surface==='folder'){event.preventDefault();event.stopImmediatePropagation();suppressClickUntil=performance.now()+600;const items=[...folder.querySelectorAll('.folder-item')];let leaf=g.target.closest('.folder-item');if(!leaf){const point=document.elementFromPoint(g.x,g.y);leaf=point?.closest('.folder-item')}if(!leaf){const sorted=items.map(item=>{const b=item.getBoundingClientRect();return{item,d:Math.hypot(g.x-b.x-b.width/2,g.y-b.y-b.height/2)}}).sort((a,b)=>a.d-b.d);leaf=sorted[0]?.item}leaf?.click()}
}
let suppressClickUntil=0;
document.addEventListener('click',event=>{if(event.isTrusted&&performance.now()<suppressClickUntil){event.preventDefault();event.stopImmediatePropagation()}},{capture:true});
document.addEventListener('touchstart',start,{capture:true,passive:true});document.addEventListener('touchmove',move,{capture:true,passive:false});document.addEventListener('touchend',end,{capture:true,passive:false});document.addEventListener('touchcancel',()=>gesture=null,{capture:true,passive:true});
// Pointer cancellation cannot turn a swipe into a modal click on touch screens.
for(const factoryName of ['createBounceLayoutGallery','createBrandAccordion']){const original=window[factoryName];if(!original)continue;window[factoryName]=function(root,...args){const gallery=original(root,...args);if(coarse.matches){const hint=root.querySelector('.ip-circular-hint,.gallery-interaction-hint');if(hint)hint.textContent='左右 / 上下滑动切换 · 点击作品查看完整图'}return gallery}}
const hint=document.createElement('div');hint.className='chapter-gesture-hint';hint.setAttribute('aria-hidden','true');hint.innerHTML='<span>↑ 05</span><span>03 ↓</span>';preview.querySelector('.chapter-frame').append(hint);
document.documentElement.dataset.touchInteractions='isolated';
})();
