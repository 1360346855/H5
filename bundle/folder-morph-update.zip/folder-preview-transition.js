(()=>{'use strict';
const folders=document.querySelector('#folders'),preview=document.querySelector('#preview'),reduced=matchMedia('(prefers-reduced-motion: reduce)');let busy=false,bypass=false,previous=document.body.dataset.section;
const frame=()=>new Promise(resolve=>requestAnimationFrame(resolve));
function box(element){const r=element?.getBoundingClientRect();return r&&r.width>0&&r.height>0?{left:r.left,top:r.top,width:r.width,height:r.height}:null}
function position(r,rotation=0){return{left:r.left+'px',top:r.top+'px',width:r.width+'px',height:r.height+'px',transform:`rotate(${rotation}deg)`}}
async function transition(link,alreadyThere=false){
 if(busy)return;busy=true;document.body.dataset.collectionTransition='opening';
 const index=Number(document.body.dataset.previewCategory||0),leaf=folders.querySelector(`.docf-paper[data-index="${index}"]`)||folders.querySelector(`[data-select="${index}"] .file-leaf`),paper=folders.querySelector('.folder-paper:not([hidden])'),title=leaf?.querySelector('strong')?.textContent||'作品预览',items=window.portfolioCollection?.(index)||[],active=preview.querySelector('.runway-work[data-depth="0"] img'),item=items.find(i=>(i.preview||i.image)===active?.getAttribute('src'))||items[0];
 const width=Math.min(300,innerWidth*.66),height=Math.min(420,innerHeight*.56),center={left:(innerWidth-width)/2,top:(innerHeight-height)/2-12,width,height},start=box(paper)||box(leaf)||center;
 const overlay=document.createElement('div'),veil=document.createElement('div'),sheet=document.createElement('div'),label=document.createElement('div'),number=document.createElement('small'),heading=document.createElement('strong');overlay.className='collection-bridge';overlay.setAttribute('aria-hidden','true');veil.className='collection-bridge-veil';sheet.className='collection-bridge-sheet';label.className='collection-bridge-label';label.textContent='03 作品文件夹  →  04 作品预览';number.textContent=String(index+1).padStart(2,'0')+' / SELECTED COLLECTION';heading.textContent=title;sheet.append(number,heading);
 if(item){const image=document.createElement('img');image.src=item.preview||item.image;image.alt='';sheet.append(image)}else{const empty=document.createElement('span');empty.className='bridge-empty';empty.textContent=String(index+1).padStart(2,'0');sheet.append(empty)}
 Object.assign(sheet.style,position(start,-4));overlay.append(veil,sheet,label);document.body.append(overlay);let navigated=alreadyThere;
 function navigate(){if(navigated)return;navigated=true;bypass=true;try{link.click()}finally{bypass=false}}
 try{
  const cover=veil.animate([{opacity:0},{opacity:1}],{duration:280,fill:'forwards'});label.animate([{opacity:0,transform:'translateY(10px)'},{opacity:1,transform:'translateY(0)'}],{duration:300,fill:'forwards'});
  await sheet.animate([position(start,-4),position(center,0)],{duration:400,easing:'cubic-bezier(.22,.75,.2,1)',fill:'forwards'}).finished;await cover.finished;
  navigate();await frame();await frame();
  const target=box(preview.querySelector('.runway-work[data-depth="0"]'))||box(preview.querySelector('.ip-circular-host,.morph-slider-stage'))||{left:innerWidth*.4,top:innerHeight*.25,width:innerWidth*.38,height:innerHeight*.5};
  veil.animate([{opacity:1},{opacity:0}],{duration:540,fill:'forwards'});label.animate([{opacity:1},{opacity:0}],{duration:250,fill:'forwards'});
  await sheet.animate([{...position(center),opacity:1,offset:0},{...position(target),opacity:1,offset:.75},{...position(target),opacity:0,offset:1}],{duration:600,easing:'cubic-bezier(.2,.7,.2,1)',fill:'forwards'}).finished;
 }finally{navigate();overlay.remove();delete document.body.dataset.collectionTransition;busy=false;previous=document.body.dataset.section}
}
document.addEventListener('click',event=>{if(bypass||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;const link=event.target.closest?.('a[href^="#"]');if(!link)return;if(busy){event.preventDefault();event.stopImmediatePropagation();return}if(link.hash!=='#preview'||document.body.dataset.section!=='folders'||document.querySelector('dialog[open]')||reduced.matches)return;event.preventDefault();event.stopImmediatePropagation();transition(link).catch(console.error)},{capture:true});
for(const type of ['wheel','touchmove','keydown'])addEventListener(type,event=>{if(!busy)return;if(type==='keydown'&&!['PageDown','PageUp','ArrowDown','ArrowUp',' '].includes(event.key))return;event.preventDefault();event.stopImmediatePropagation()},{capture:true,passive:false});
addEventListener('scroll',()=>{const current=document.body.dataset.section;if(!busy&&!reduced.matches&&previous==='folders'&&current==='preview'&&!document.querySelector('dialog[open]'))transition(document.querySelector('[data-nav="preview"]'),true).catch(console.error);previous=current},{passive:true});
})();
