(()=>{'use strict';
const folders=document.querySelector('#folders'),next=document.querySelector('[data-nav="preview"]');let touch=null;
function available(event){return document.body.dataset.section==='folders'&&!document.querySelector('dialog[open]')&&!event.target.closest?.('.folder-list,.document-folder,input,textarea,select,[contenteditable="true"]')}
function enter(){next.click();touch=null}
addEventListener('wheel',event=>{if(event.defaultPrevented||event.ctrlKey||!available(event)||event.deltaY<8||Math.abs(event.deltaX)>Math.abs(event.deltaY))return;event.preventDefault();if(folders.dataset.contentReady==='true')enter()},{passive:false});
addEventListener('touchstart',event=>{if(available(event)&&event.touches.length===1)touch={x:event.touches[0].clientX,y:event.touches[0].clientY};else touch=null},{passive:true});
addEventListener('touchmove',event=>{if(!touch||!available(event)||event.touches.length!==1)return;const point=event.touches[0],dy=touch.y-point.clientY,dx=point.clientX-touch.x;if(dy<38||Math.abs(dx)>dy)return;event.preventDefault();if(folders.dataset.contentReady==='true')enter()},{passive:false});
addEventListener('touchend',()=>touch=null,{passive:true});
addEventListener('keydown',event=>{if(event.defaultPrevented||!available(event)||(event.key===' '&&event.target.closest?.('button,a'))||!['PageDown','ArrowDown',' '].includes(event.key))return;event.preventDefault();if(folders.dataset.contentReady==='true')enter()});
})();
